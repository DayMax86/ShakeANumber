package com.daymax86.shakeanumber;

public class Game {
	/*
	
	public enum diceNumbers
	{
		ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,BLANK;
	}

	public static void main() {
		// TODO Auto-generated method stub
		Player playerOne = new Player("PlayerOne");
		Player playerTwo = new Player("PlayerTwo");
		DottedDice spotDice1 = new DottedDice();
		DottedDice spotDice2 = new DottedDice();
		NumberedDice numDice1 = new NumberedDice();
		NumberedDice numDice2 = new NumberedDice();
		int dot1;
		int dot2;
		dot1 = spotDice1.rollDottedDice();
		dot2 = spotDice2.rollDottedDice();
		int num1;
		int num2;
		num1 = numDice1.rollNumberedDice();
		num2 = numDice2.rollNumberedDice();
		System.out.println("1st DottedDice value : " + dot1 + ", " + spotDice1.number);
		System.out.println("2nd DottedDice value : " + dot2 + ", " + spotDice2.number);
		System.out.println("1st NumberedDice value : " + num1 + ", " + numDice1.number);
		System.out.println("2nd NumberedDice value : " + num2 + ", " + numDice2.number);
	}

	*/
}
