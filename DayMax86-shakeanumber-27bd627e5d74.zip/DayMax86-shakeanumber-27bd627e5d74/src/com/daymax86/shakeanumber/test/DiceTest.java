package com.daymax86.shakeanumber.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class DiceTest {

	@Test
	public void testNumberedDice() {
		fail("Not yet implemented");
	}

	@Test
	public void testRollNumberedDice() {
		fail("Not yet implemented");
	}

}
